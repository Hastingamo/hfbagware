document.addEventListener("DOMContentLoaded", () =>{
    const loginForm = document.querySelector("#sing");
    const signForm = document.querySelector("#createAccount");
    document.querySelector("#LinkCreateAccount").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.add("form-hidden");
        signForm.classList.remove("form-hidden");
    });
    document.querySelector("#LinkLogin").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.remove("form-hidden");
        signForm.classList.add("form-hidden");
        loginForm.classList.add("form-box");

    });
});
